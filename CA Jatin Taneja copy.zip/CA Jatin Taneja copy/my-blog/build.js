const fs = require('fs');
const path = require('path');

const template = fs.readFileSync('template.html', 'utf8');
const posts = JSON.parse(fs.readFileSync('posts.json', 'utf8'));

const distDir = path.join(__dirname, 'dist');
const postsDir = path.join(distDir, 'posts');
fs.mkdirSync(postsDir, { recursive: true });

let postListHtml = '';

posts.forEach(post => {
    let finalHtml = template
        .replace(/{{title}}/g, post.title)
        .replace(/{{date}}/g, post.date)
        .replace(/{{content}}/g, post.content);

    const filePath = path.join(postsDir, `${post.slug}.html`);
    fs.writeFileSync(filePath, finalHtml);

    // Handle custom external links if provided, otherwise link to the generated post page
    const readMoreUrl = post.link && post.link.trim() !== '' ? post.link : `posts/${post.slug}.html`;
    const targetAttr = post.link && post.link.trim() !== '' ? 'target="_blank"' : '';

    postListHtml += `
        <div class="bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group">
            <div class="p-6">
                <div class="text-xs text-slate-400 mb-2"><span><i class="fa-regular fa-calendar mr-1"></i> ${post.date}</span></div>
                <h3 class="font-bold text-navy-900 text-lg leading-snug mb-3 group-hover:text-gold-600 transition-colors">
                    <a href="${readMoreUrl}" ${targetAttr}>${post.title}</a>
                </h3>
                <p class="text-xs text-slate-600 line-clamp-3 leading-relaxed mb-4">Explore authoritative analysis and professional insights on ${post.title}.</p>
            </div>
            <div class="px-6 pb-6 pt-0 flex items-center justify-between border-t border-slate-100 pt-4">
                <span class="text-xs text-slate-500 font-semibold"><i class="fa-solid fa-user mr-1"></i> GPC Academic Board</span>
                <a href="${readMoreUrl}" ${targetAttr} class="bg-navy-900 hover:bg-gold-500 hover:text-navy-950 text-white text-xs font-bold px-4 py-2 rounded-lg transition">
                    Read Article <i class="fa-solid fa-arrow-right ml-1 text-[10px]"></i>
                </a>
            </div>
        </div>
    `;
});

const blogIndexHtml = `
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Executive Insights & Thought Leadership Blog | Global Premier Centre (GPC)</title>
    <!-- Tailwind CSS via CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        navy: { 800: '#0d2540', 900: '#07162b', 950: '#040d1a' },
                        gold: { 400: '#facc15', 500: '#df9b3a', 600: '#c88523' }
                    }
                }
            }
        }
    </script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-slate-50 text-slate-800 flex flex-col min-h-screen">

    <!-- TOP ANNOUNCEMENT BAR -->
    <div class="bg-navy-950 text-slate-300 text-xs py-2 px-4 border-b border-slate-800">
        <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
            <div class="flex items-center gap-6">
                <span class="flex items-center gap-2"><i class="fa-solid fa-ribbon text-gold-500"></i> ISO 9001:2015 & ISO 45001 Certified Institution</span>
            </div>
            <div class="flex items-center gap-4 text-xs">
                <a href="tel:+442072471452" class="hover:text-gold-400 transition-colors"><i class="fa-solid fa-phone text-gold-500 mr-1"></i> +44 20 7247 1452</a>
            </div>
        </div>
    </div>

    <!-- MAIN HEADER / NAVIGATION -->
   

    <!-- HERO SECTION -->
    <section class="relative bg-navy-900 text-white py-16 lg:py-20 overflow-hidden border-b border-slate-800">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="max-w-3xl">
                <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gold-500/10 border border-gold-500/30 text-gold-400 text-xs font-semibold mb-6">
                    <i class="fa-solid fa-pen-nib"></i> Executive Insights & Research Publications
                </div>
                <h1 class="text-3xl md:text-5xl font-extrabold tracking-tight mb-6 leading-tight">
                    Thought Leadership & <span class="text-transparent bg-clip-text bg-gradient-to-r from-gold-400 to-gold-600">Industry Perspectives</span>
                </h1>
                <p class="text-lg text-slate-300 leading-relaxed">
                    Explore authoritative analyses, regulatory updates, ISO management guidelines, and strategic management case studies published by GPC's academic board.
                </p>
            </div>
        </div>
    </section>

    <!-- MAIN CONTENT GRID -->
    <main class="py-16 bg-slate-50 flex-1">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                ${postListHtml}
            </div>
        </div>
    </main>

    <!-- FOOTER -->
    <footer class="bg-navy-950 text-slate-300 pt-12 pb-8 border-t border-navy-800">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-500">
            <p>&copy; 2026 Global Premier Centre (GPC) Executive Education. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
`;

fs.writeFileSync(path.join(distDir, 'blog.html'), blogIndexHtml);
console.log('✅ Build updated: Header links disabled, logo links back to home.');