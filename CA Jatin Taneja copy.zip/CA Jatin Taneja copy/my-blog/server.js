const express = require('express');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const app = express();
const PORT = 3000;
const ADMIN_PASSWORD = "YourSecurePassword123"; // Change to your staff password

// Middleware to read form data
app.use(express.urlencoded({ extended: true }));

// Helper function to trigger build.js safely
function runBuild(callback) {
    exec('node build.js', { cwd: __dirname }, (error, stdout, stderr) => {
        if (error) {
            console.log("❌ Build failed:", error.message);
        } else {
            console.log("🎉 Build completed successfully!");
        }
        if (callback) callback(error);
    });
}

// 1. Admin Dashboard (Lists posts & shows add form)
app.get('/admin', (req, res) => {
    const postsFilePath = path.join(__dirname, 'posts.json');
    let posts = [];
    if (fs.existsSync(postsFilePath)) {
        posts = JSON.parse(fs.readFileSync(postsFilePath, 'utf8'));
    }

    // Generate HTML list of current posts with Delete buttons
    let postsListHtml = posts.map(post => `
        <div class="flex items-center justify-between bg-slate-900 p-4 rounded-xl border border-slate-700 mb-3">
            <div>
                <h4 class="font-bold text-white text-sm">${post.title}</h4>
                <p class="text-xs text-slate-400">Published: ${post.date} | Slug: ${post.slug}</p>
            </div>
            <form action="/delete" method="POST" onsubmit="return confirm('Are you sure you want to delete this post?');">
                <input type="hidden" name="slug" value="${post.slug}">
                <input type="password" name="password" required placeholder="Password" class="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-xs text-white w-24 mr-2">
                <button type="submit" class="px-3 py-1 bg-red-600 hover:bg-red-500 text-white rounded text-xs font-bold transition">Delete</button>
            </form>
        </div>
    `).join('') || '<p class="text-slate-400 text-xs">No posts found.</p>';

    // Send complete admin UI page
    res.send(`
        <!DOCTYPE html>
        <html lang="en" class="scroll-smooth">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Staff Blog Admin | GPC</title>
            <script src="https://cdn.tailwindcss.com"></script>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        </head>
        <body class="bg-slate-950 text-slate-100 min-h-screen p-6">
            <div class="max-w-3xl mx-auto space-y-8">
                
                <!-- HEADER -->
                <div class="flex justify-between items-center bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl">
                    <div>
                        <h1 class="text-xl font-bold">GPC Blog Management</h1>
                        <p class="text-xs text-slate-400 mt-0.5">Publish and manage executive insights from the backend</p>
                    </div>
                    <a href="dist/blog.html" target="_blank" class="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded-lg text-xs transition">View Live Blog ↗</a>
                </div>

                <!-- PUBLISH NEW POST FORM -->
                <div class="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl">
                    <h2 class="text-lg font-bold mb-4 text-amber-400"><i class="fa-solid fa-pen-to-square mr-2"></i>Publish New Article</h2>
                    <form action="/publish" method="POST" class="space-y-4">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-semibold text-slate-300 mb-1">Admin Password *</label>
                                <input type="password" name="password" required placeholder="Enter password" class="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-amber-500">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-300 mb-1">Publish Date *</label>
                                <input type="text" name="date" required value="October 21, 2026" class="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-amber-500">
                            </div>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-300 mb-1">Article Title *</label>
                            <input type="text" name="title" required placeholder="e.g., Executive Leadership Trends 2026" class="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-amber-500">
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-300 mb-1">Article Content (HTML allowed) *</label>
                            <textarea name="content" rows="5" required placeholder="&lt;p&gt;Write your article paragraphs here...&lt;/p&gt;" class="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-amber-500"></textarea>
                        </div>

                        <button type="submit" class="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold rounded-lg text-sm transition shadow-md">
                            Publish Article Instantly
                        </button>
                    </form>
                </div>

                <!-- EXISTING POSTS LIST -->
                <div class="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl">
                    <h2 class="text-lg font-bold mb-4 text-amber-400"><i class="fa-solid fa-list mr-2"></i>Existing Articles (${posts.length})</h2>
                    <div class="space-y-2">
                        ${postsListHtml}
                    </div>
                </div>

            </div>
        </body>
        </html>
    `);
});

// 2. Handle Publishing Form Submission
app.post('/publish', (req, res) => {
    const { password, title, date, content } = req.body;

    if (password !== ADMIN_PASSWORD) {
        return res.send("<h3 style='color:red; font-family:sans-serif; text-align:center; margin-top:50px;'>Incorrect Password! <a href='/admin'>Go Back</a></h3>");
    }

    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    const postsFilePath = path.join(__dirname, 'posts.json');
    let posts = [];
    
    if (fs.existsSync(postsFilePath)) {
        posts = JSON.parse(fs.readFileSync(postsFilePath, 'utf8'));
    }

    posts.unshift({ slug, title, date, content });
    fs.writeFileSync(postsFilePath, JSON.stringify(posts, null, 2));

    runBuild((err) => {
        if (err) {
            return res.send(`<h3 style='color:red; font-family:sans-serif; text-align:center; margin-top:50px;'>Saved to JSON, but build failed. <a href='/admin'>Go Back</a></h3>`);
        }
        res.send("<h3 style='color:green; font-family:sans-serif; text-align:center; margin-top:50px;'>🎉 Article published successfully! <a href='/admin'>← Back to Admin Dashboard</a></h3>");
    });
});

// 3. Handle Deleting Posts
app.post('/delete', (req, res) => {
    const { slug, password } = req.body;

    if (password !== ADMIN_PASSWORD) {
        return res.send("<h3 style='color:red; font-family:sans-serif; text-align:center; margin-top:50px;'>Incorrect Password! <a href='/admin'>Go Back</a></h3>");
    }

    const postsFilePath = path.join(__dirname, 'posts.json');
    if (!fs.existsSync(postsFilePath)) {
        return res.send("<h3 style='color:red; font-family:sans-serif; text-align:center; margin-top:50px;'>No posts found. <a href='/admin'>Go Back</a></h3>");
    }

    let posts = JSON.parse(fs.readFileSync(postsFilePath, 'utf8'));
    
    // Filter out the post to be deleted
    const updatedPosts = posts.filter(p => p.slug !== slug);
    fs.writeFileSync(postsFilePath, JSON.stringify(updatedPosts, null, 2));

    // Also delete the physical HTML file from dist/posts/
    const postHtmlPath = path.join(__dirname, 'dist', 'posts', `${slug}.html`);
    if (fs.existsSync(postHtmlPath)) {
        fs.unlinkSync(postHtmlPath);
        console.log(`🗑️ Deleted physical file: ${slug}.html`);
    }

    // Rebuild the site so the blog listing updates
    runBuild((err) => {
        if (err) {
            return res.send(`<h3 style='color:red; font-family:sans-serif; text-align:center; margin-top:50px;'>Post deleted from JSON, but rebuild failed. <a href='/admin'>Go Back</a></h3>`);
        }
        res.send("<h3 style='color:green; font-family:sans-serif; text-align:center; margin-top:50px;'>🗑️ Article deleted successfully! <a href='/admin'>← Back to Admin Dashboard</a></h3>");
    });
});

app.listen(PORT, () => {
    console.log(`🚀 Admin server running! Open http://localhost:3000/admin in your browser.`);
});